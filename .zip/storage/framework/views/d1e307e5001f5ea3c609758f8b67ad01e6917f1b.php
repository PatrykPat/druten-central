<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <!-- steven 13-5-2024  -->
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold bg-transparent text-center text-4xl text-white leading-tight">
            <?php echo e(__('beheer coupons')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <h2 class="font-semibold bg-transparent text-center text-4xl text-white leading-tight">
    <div class="alert alert-danger p-6 bold-xl text-[#FF0000]">
                        <?php echo e(session('error')); ?>

                </div>
    <div class="alert alert-success p-6 bold-xl text-[#FF0000]">
        <?php echo e(session('success')); ?>

    </div>
</h2>
    <div class="py-12 min-h-screen flex flex-col justify-center items-center pt-6 pt-0 bg-transparent">
        <div class="max-w-7xl mx-auto px-8">
            <div class="bg-transparent overflow-hidden">
                <div class="p-6 text-black">
                    <?php $__currentLoopData = $Coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-4 mb-6 border rounded-3xl bg-white flex flex-col justify-center items-center">
                            <h2><?php echo e($Coupon->id); ?></h2>
                            <p><?php echo e($Coupon->Omschrijving); ?></p>
                            <p>korting: <?php echo e($Coupon->Waarde); ?><?php echo e($Coupon->Eenheid); ?></p>
                            <a href="<?php echo e(route('coupon.edit', $Coupon->id)); ?>">Bewerk</a>
                            <form action="<?php echo e(route('coupon.delete', $Coupon->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit">Verwijder</button>
                            </form>
                        </div><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\steven\Documents\druten-central\resources\views/coupons/readcoupons.blade.php ENDPATH**/ ?>