<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

 <?php $__env->slot('header', null, ['class' => 'bg-transparent']); ?> 
        <h2 class="font-semibold bg-transparent text-center text-4xl text-white leading-tight">
            <?php echo e(__('feedbackvraag antwoorden')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 w-full">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="flex justify-end"></div>
                    <ul role="list" class="divide-y divide-gray-100">
                        <?php $__currentLoopData = $vragen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vraag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($vraag->user_userid == auth()->id()): ?>
                                <?php $__currentLoopData = $antwoorden; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $antwoord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($antwoord->Vragen_idVragen == $vraag->id): ?>
                        <!-- Een lijstitem voor de weergave van vraag en bijbehorend antwoord -->
                        <li class="flex justify-between gap-x-6 py-5">
                            <!-- Gedeelte voor vraaginformatie -->
                            <div class="flex min-w-0 gap-x-4">
                                <div class="min-w-0 flex-auto">
                                    <!-- Weergave van de vraagtitel -->
                                    <p class="text-sm leading-6 text-gray-900">Vraag: <?php echo e($vraag->title); ?> </p></br>
                                </div>
                            </div>
                            <div class="flex min-w-0 gap-x-4">
                                <div class="min-w-0 flex-auto">
                                    <!-- Weergave van de vraagtitel -->
                                    <p class="text-sm leading-6 text-gray-900">komt van: <?php echo e(Auth::user()->name); ?> </p>
                                    </br>
                                </div>
                            </div>
                            <!-- Gedeelte voor antwoordinformatie -->
                            <div class="hidden shrink-0 sm:flex sm:flex-col sm:items-end">
                                <!-- Weergave van gebruikersantwoord en gebruikers-ID -->
                                <p class="text-sm leading-6 text-gray-900"><?php echo e($antwoord->gebruiker->name); ?> zegt: <?php echo e($antwoord->antwoord); ?></p></br>
                            </div>
                            <!-- Gedeelte voor beoordelingsinformatie -->
                            <div class="hidden shrink-0 sm:flex sm:flex-col sm:items-end">
                                <!-- Weergave van de beoordeling (positief/negatief) -->
                                <p class="text-sm leading-6 text-gray-900">Rating:
                                    <?php if($antwoord->rating > 5): ?>
                                    <span class="text-sm leading-6 text-gray-900">Positief</span>
                                    <?php else: ?>
                                    <span class="text-sm leading-6 text-gray-900">Negatief</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\steven\Documents\druten-central\resources\views/Feedbackantwoorden.blade.php ENDPATH**/ ?>