 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('header', null, ['class' => 'bg-transparent']); ?> 
            <h2 class="font-semibold bg-transparent text-center text-4xl text-white leading-tight">
                <?php echo e(__('Nieuws')); ?>

            </h2>
         <?php $__env->endSlot(); ?>
            <div class="max-w-7xl mx-auto px-8 pb-12">
                <!-- Dropdown-formulier om nieuwsitems te filteren -->
                <form id="filterForm" action="<?php echo e(route('nieuws.filter')); ?>" class="m-6 bg-[color:var(--prime-color)] rounded-xl" method="GET">
                    <?php echo csrf_field(); ?>
                    <label class="p-3 text-white" for="userFilter">Kies een gebruiker:</label>
                    <select id="userFilter" name="user_postcode">
                        <option value="<?php echo e(empty($selectedUserPostcode) ? 'selected' : ''); ?>">Alle gebruikers</option>
                        <!-- foreach die alle gebruikers laat zien met de rol bedrijf -->
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($role->name == 'bedrijf'): ?>
                                    <option value="<?php echo e($user->postcode); ?>" <?php echo e(isset($selectedUserPostcode) && $selectedUserPostcode == $user->
                postcode ? 'selected' : ''); ?>>
                                        <?php echo e($user->name); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>

                <script>
                    // Filter automatisch met JavaScript
                    document.getElementById('userFilter').addEventListener('change', function () {
                        document.getElementById('filterForm').submit();
                    });
                </script>

                <!-- Foreach die alle nieuwsartikelen laat zien die van eerder dan vandaag zijn -->
                <?php $__currentLoopData = $nieuws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nieuwsitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-6 text-black border rounded-3xl bg-white flex flex-col justify-center items-center">
                        <div class="w-full p-3 justify-center font-bold text-base block sm:flex">
                            <?php if($nieuwsitem->image): ?>
                                <div class="font-bold text-base flex sm:flex justify-center">
                                    <img class="w-full max-w-[300px] rounded-xl" src="data:image/png;base64,<?php echo e(chunk_split(base64_encode($nieuwsitem->image))); ?>">
                                </div>
                            <?php endif; ?>

                            <div class="w-full p-3 flex flex-col">
                                <h3 class="uppercase text-xl pb-2"><?php echo e($nieuwsitem->title); ?></h3>
                                <h4 class="capitalize pb-12"><?php echo e($nieuwsitem->beschrijving); ?></h4>
                                <h3>Gebruiker: <?php if($nieuwsitem->gebruiker): ?>
                                    <?php echo e($nieuwsitem->gebruiker->name); ?>

                                <?php else: ?>
                                    <p class="text-[#FF0000]">Geen gebruiker gevonden</p>
                                <?php endif; ?>
                                </h3>
                                <h4>date: <?php echo e($nieuwsitem->datum); ?></h4>
                                <h4>postcode: <?php echo e($nieuwsitem->postcode); ?></h4>
                            </div>
                        </div>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'bedrijf')): ?>
                                <a href="<?php echo e(route('nieuws.NieuwsEdit', $nieuwsitem->id)); ?>">Bewerk</a>

                                <form method="post" action="<?php echo e(route('nieuws.destroy', $nieuwsitem->id)); ?>" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" onclick="return confirm('Are you sure you want to delete this news item?')">Verwijder</button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(auth()->guard()->check()): ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'bedrijf')): ?>
                        <h3><a href="/create">Creëren</a></h3>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\steven\Documents\druten-central\resources\views/nieuws/nieuwsArchief.blade.php ENDPATH**/ ?>