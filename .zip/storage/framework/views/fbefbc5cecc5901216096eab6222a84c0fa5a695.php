<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold bg-transparent text-center text-4xl text-white leading-tight">
            <?php echo e(__('coupons')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 min-h-screen flex flex-col justify-center items-center pt-6 pt-0 bg-transparent">
            <div class="max-w-7xl mx-auto px-8">
                <div class="bg-transparent overflow-hidden">
                    <div class="p-6 text-black">

    <div class="alert alert-success p-6 bold-xl text-[#FF0000]">
        <?php echo e(session('success')); ?>

    </div>
    


    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="p-4 mb-6 border rounded-3xl bg-white flex flex-col justify-center items-center">
            <h2><?php echo e($coupon->coupon->id); ?></h2>
            <p><?php echo e($coupon->coupon->Omschrijving); ?></p>
            <p>korting: <?php echo e($coupon->coupon->Waarde); ?><?php echo e($coupon->coupon->Eenheid); ?></p>
            <p>gekocht op: <?php echo e($coupon->created_at); ?></p>
            <button onclick="toggleQrCode(<?php echo e($coupon->id); ?>)">Toon QR-code</button>
            <div id="qrcode_<?php echo e($coupon->id); ?>" style="display: none;">
                <?php echo QrCode::generate("<?php echo e($coupon->coupon->Waarde); ?><?php echo e($coupon->coupon->Eenheid); ?><?php echo e($coupon->id); ?>"); ?>

            </div>
        </div><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
        function toggleQrCode(couponId) {
            var qrCode = document.getElementById('qrcode_' + couponId);
            if (qrCode.style.display === 'none') {
                qrCode.style.display = 'block';
            } else {
                qrCode.style.display = 'none';
            }
        }
    </script>

    </div>
    </div>
    </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\steven\Documents\druten-central\resources\views/coupons\usercoupon.blade.php ENDPATH**/ ?>