<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, ['class' => 'bg-transparent']); ?> 
        <h2 class="font-semibold bg-transparent text-center text-4xl text-white leading-tight">
            <?php echo e(__('Meerkeuzevraag')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <!-- <div class="alert alert-success">
        <?php echo e(session('niks')); ?>

    </div> -->

    <div class="py-12 min-h-screen flex flex-col justify-center items-center pt-6 pt-0 bg-transparent">
            <div class="max-w-7xl mx-auto px-8">
                <div class="bg-transparent overflow-hidden">
                    <div class="p-6 text-black">
                        <?php if( session('error') ): ?> 
                            <div class="alert alert-error bg-white p-3 mb-3 text-[#ff0000] rounded-3xl">
                                <?php echo e(session('error')); ?>

                            </div>
                            <?php elseif( session('success')): ?>
                                <div class="alert alert-success bg-white p-3 mb-3 text-[color:var(--prime-color)] rounded-3xl">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            
                        <!-- meerkeuzevraag loop-->
                        <?php if(count($vragenMetAntwoorden) > 0): ?>
                            <?php $__currentLoopData = $vragenMetAntwoorden; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vraag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form method="POST" class="p-4 mb-6 border rounded-3xl bg-white flex flex-col justify-center items-center" action="<?php echo e(route('meerkeuzevragen.control')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <h2 class="font-bold text-xl"><?php echo e($vraag->vraag); ?></h2>
                                    <div class="grid w-full grid-rows-2 grid-flow-col gap-4 bg-[color:var(--prime-color)] p-8 rounded-3xl">
                                        <?php $__currentLoopData = $vraag->antwoorden; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $antwoord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="block">
                                            <input class="peer hidden" type="checkbox" id="antwoord[<?php echo e($antwoord->antwoordID); ?>]" name="antwoord[<?php echo e($antwoord->antwoordID); ?>]" value="<?php echo e($antwoord->antwoordID); ?>"> 
                                                <label for="antwoord[<?php echo e($antwoord->antwoordID); ?>]" class="select-none block bg-[color:var(--sec-color)] rounded-3xl cursor-pointer p-4 font-bold text-white text-center transition-colors duration-200 ease-in-out peer-checked:bg-white peer-checked:text-[color:var(--prime-color)]"><?php echo e($antwoord->AntwoordTekst); ?>

                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <input type="hidden" name="vraag_id" value="<?php echo e($vraag->id); ?>">

                                    <div class="m-4 w-full flex flex-colm justify-center items-center">
                                        <button class="text-white w-[90%] justify-center  w-full relative inset-x-0 bottom-0 h-12 bg-[var(--prime-color)] border-black rounded-3xl" type="submit">Controleer antwoord</button>
                                    </div>        
                                </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!--melding dat er geen berichten zijn-->
                        <?php else: ?>
                            <p class="p-4 mb-6 border rounded-3xl bg-white flex flex-col justify-center items-center">er zijn geen openstaande meerkeuzevragen</p>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\steven\Documents\druten-central\resources\views/vragen\meerkeuzervraag.blade.php ENDPATH**/ ?>