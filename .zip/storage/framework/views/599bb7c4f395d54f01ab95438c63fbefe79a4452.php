<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold bg-transparent text-center text-4xl text-white leading-tight">
            <?php echo e(__('Kalender')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    
    <html>
        <body>
            <h1>Aankomende nieuwsberichten:</h1>
            <form id="filterForm" action="<?php echo e(route('nieuws.filterkalender')); ?>" method="GET">
                <?php echo csrf_field(); ?>
                <label for="userFilter">Selecteer gebruiker:</label>
                <select id="userFilter" name="user_postcode">
                    <option value="" <?php echo e(empty($selectedUserPostcode) ? 'selected' : ''); ?>>Alle gebruikers</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($role->name == 'bedrijf'): ?>
                                <option value="<?php echo e($user->postcode); ?>" <?php echo e(isset($selectedUserPostcode) && $selectedUserPostcode == $user->postcode ? 'selected' : ''); ?>>
                                    <?php echo e($user->name); ?>

                                </option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>

            <?php $__currentLoopData = $nieuws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nieuwsitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="nieuwsitembox">
                    <h3>User: <?php if($nieuwsitem->gebruiker): ?>
                        <?php echo e($nieuwsitem->gebruiker->name); ?>

                    <?php else: ?>
                        Geen gebruiker gevonden
                    <?php endif; ?></h3>
                    <h3>Title: <?php echo e($nieuwsitem->title); ?></h3>
                    <h4>Description: <?php echo e($nieuwsitem->beschrijving); ?></h4>
                    <h4>Date: <?php echo e($nieuwsitem->datum); ?></h4>
                    <h4>Postcode: <?php echo e($nieuwsitem->postcode); ?></h4>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'bedrijf')): ?>
                            <a href="<?php echo e(route('nieuws.NieuwsEdit', $nieuwsitem->id)); ?>">Edit</a>

                            <form method="post" action="<?php echo e(route('nieuws.destroy', $nieuwsitem->id)); ?>" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Are you sure you want to delete this news item?')">Delete</button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                </div><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(auth()->guard()->check()): ?>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'bedrijf')): ?>
                    <h3><a href="/nieuws/create">Create</a></h3>
                <?php endif; ?>
            <?php endif; ?>

            <script>
                document.getElementById('userFilter').addEventListener('change', function () {
                    document.getElementById('filterForm').submit();
                });
            </script>
        </body>
    </html>  
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\steven\Documents\druten-central\resources\views/nieuws/nieuwsKalender.blade.php ENDPATH**/ ?>