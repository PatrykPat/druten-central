<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold bg-transparent text-center text-4xl text-white leading-tight">
            <?php echo e(__('Maak meerkeuzevraag')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

            <div class="alert alert-error">
                <?php echo e(session('error')); ?>

            </div>

            <div class="py-12">
        <div class="max-w-2xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                <div class="max-w-xl ">
                <form method="POST"  action="<?php echo e(route('verwerk_vraag')); ?>">
                <?php echo csrf_field(); ?>
                <div class="flex flex-col ">
                    <label for="vraag">Vraag:</label>
                        <input type="text" id="vraag" name="vraag" required>
                        <br>
                        <label for="opties">vink het juiste antwoord(en) aan. voer hier de opties in:</label>

                        <div id="opties-container">
                            <div class="optie">
                                <input type="text" name="opties[0][tekst]" required>
                                <input type="checkbox" name="opties[0][is_correct]" value="1">
                            </div>
                            <div class="optie">
                                <input type="text" name="opties[1][tekst]" required>
                                <input type="checkbox" name="opties[1][is_correct]" value="1">
                            </div>
                            <div class="optie">
                                <input type="text" name="opties[2][tekst]" required>
                                <input type="checkbox" name="opties[2][is_correct]" value="1">
                            </div>
                            <div class="optie">
                                <input type="text" name="opties[3][tekst]" required>
                                <input type="checkbox" name="opties[3][is_correct]" value="1">
                            </div>
                        </div>
                    <label for="punten">hoeveel punten moet de gebruiker krijgen:</label>

                    <input type="number" id="punten" name="punten" required><br>
                        <div class="w-full flex flex-colm justify-center items-center">
	                        <button class="text-white w-[90%] justify-center  w-full relative inset-x-0 bottom-0 h-12 bg-[var(--prime-color)] border-black rounded-3xl" type="submit">verstuur</button>
                        </div> 
                    </div>
                </form>
            </div>
            </div>
            </div>
            </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\steven\Documents\druten-central\resources\views/vragen\Meerkeuzevragen.blade.php ENDPATH**/ ?>