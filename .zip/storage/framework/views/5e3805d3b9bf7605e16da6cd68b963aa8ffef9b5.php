<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div class="py-12 w-full">
        <?php $__currentLoopData = $vragen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vraag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-hidden shadow-sm sm:rounded-lg">
                <div class= " bg-white p-6 text-gray-900" >
                    <div class="flex">
                        </div>
                            <ul role="list" class="divide-y divide-gray-100">
                        </div>    
                            <!-- Een formulier voor het verwerken van het antwoord -->
                            <form method="POST" action="<?php echo e(route('verwerkantwoord')); ?>">
                                <?php echo csrf_field(); ?> <!-- Cross-Site Request Forgery-beveiligingstoken -->

                                <!-- Verborgen veld om de vraag-ID door te geven -->
                                <input type="hidden" name="vraag_id" value="<?php echo e($vraag->id); ?>">

                                <!-- Label voor het weergeven van de vraag -->
                                <label for="antwoord"><?php echo e($vraag->beschrijving); ?></label><br>

                                <!-- Invoerveld voor het beantwoorden van de vraag -->
                                <input type="text" id="antwoord" name="antwoord" required>

                                <!-- Een schuifregelaar voor het beoordelen van de vraag -->
                                <div class="slidecontainer">
                                    <p>Standaard bereikschuifregelaar:</p>
                                    <input type="range" id="rating" name="rating" required min="1" max="10" value="10" oninput="updateHiddenField(this.value)">
                                    <!-- Verborgen veld om de geselecteerde waarde van de schuifregelaar bij te houden -->
                                    <input type="hidden" id="hiddenValue" name="hiddenValue" value="10">
                                    <!-- Knop om het antwoord in te dienen -->

                                    <?php if(auth()->guard()->check()): ?>
            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'bedrijf')): ?>
                <h3><a href="/nieuws/create">Create</a></h3>
            <?php endif; ?>
        <?php endif; ?>
                                            <input type="submit" value="Beantwoorden">
                                </div>
                            </form>
</div>                  
</div>
</div>                  
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<!-- JavaScript-functie om het verborgen veld bij te werken wanneer de schuifregelaar wordt gewijzigd -->
<script>
    function updateHiddenField(value) {
        document.getElementById('hiddenValue').value = parseInt(value, 10);
    }
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\steven\Documents\druten-central\resources\views/vragen\Meer-vragen.blade.php ENDPATH**/ ?>