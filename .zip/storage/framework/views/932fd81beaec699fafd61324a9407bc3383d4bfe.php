<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, ['class' => 'bg-transparent']); ?> 
        <h2 class="font-semibold bg-transparent text-center text-4xl text-white leading-tight">
            <?php echo e(__('Feedbackvragenformulier')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <html>
        <body>
            <h2>Maak een feedbackvraag</h2>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <form method="POST" action="<?php echo e(route('feedback.send')); ?>">
                <?php echo csrf_field(); ?>
                <label for="title">Titel:</label><br>
                <input type="text" id="title" name="title"><br><br>

                <label for="beschrijving">Beschrijving:</label><br>
                <textarea id="beschrijving" name="beschrijving"></textarea><br><br>

                <label for="puntenTeVerdienen">Punten te verdienen:</label><br>
                <input type="number" id="puntenTeVerdienen" name="puntenTeVerdienen"><br><br>

                <button type="submit">Verzenden</button>
            </form>
        </body>
    </html>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\steven\Documents\druten-central\resources\views/vragen\Feedbackvragenform.blade.php ENDPATH**/ ?>