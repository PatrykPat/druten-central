<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'inline-flex items-center hover:bg-[var(--sec-color)] px-4 py-2 border border-transparent rounded-md font-semibold text-white uppercase tracking-widest transition ease-in-out duration-150'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\steven\Documents\druten-central\resources\views/components/primary-button.blade.php ENDPATH**/ ?>