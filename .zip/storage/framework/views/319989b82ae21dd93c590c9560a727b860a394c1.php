<!-- Form voor het creëren van nieuwsitems -->
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, ['class' => 'bg-transparent']); ?> 
        <h2 class="font-semibold bg-transparent text-center text-4xl text-white leading-tight">
            <?php echo e(__('Create nieuws')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-2xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                <div class="max-w-xl flex flex-col">



    <form method="post" action="<?php echo e(url('/newnieuws')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="flex flex-col ">

        <label for="title">Title:</label>
        <input type="text" name="title" required>

        <label for="beschrijving">Description:</label>
        <textarea name="beschrijving" required></textarea>

        <label for="image">Image:</label>
        <input type="file" name="image">

        <label for="datum">Date:</label>
        <input type="date" name="datum" required>

        <label for="postcode">Postcode:</label>
        <input type="text" name="postcode" required>

        <div class="m-4 w-full flex flex-colm justify-center items-center">
            <button class="text-white w-[90%] justify-center  w-full relative inset-x-0 bottom-0 h-12 bg-[var(--prime-color)] border-black rounded-3xl" type="submit">Maken</button>
        </div> 
    </form>

</div>
</div>
</div>
</div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\steven\Documents\druten-central\resources\views/nieuws/createNieuws.blade.php ENDPATH**/ ?>